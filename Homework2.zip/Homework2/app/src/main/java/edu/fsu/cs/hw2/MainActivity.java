package edu.fsu.cs.hw2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnLin;
    private Button btnRel;
    private Button btnTab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLin = (Button) findViewById(R.id.button);
        btnRel = (Button) findViewById(R.id.button2);
        btnTab = (Button) findViewById(R.id.button3);

        btnLin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLinearActivity();
            }
        });

        btnRel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRelativeActivity();
            }
        });

        btnTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTableActivity();
            }
        });
    }

    public void openLinearActivity() {
        Intent intent = new Intent(this, LinearLayoutActivity.class);
        startActivity(intent);
    }

    public void openRelativeActivity() {
        Intent intent = new Intent(this, RelativeLayoutActivity.class);
        startActivity(intent);
    }

    public void openTableActivity() {
        Intent intent = new Intent(this, TableLayoutActivity.class);
        startActivity(intent);
    }
}
