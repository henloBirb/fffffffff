package edu.fsu.cs.hw2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;

public class LinearLayoutActivity extends AppCompatActivity {

    Button clearBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linear_layout);

        clearBtn = findViewByID(R.id.resetBtn1);



    }
}
